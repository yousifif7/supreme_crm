<?php $page = 'addproduct'; ?>
@extends('layouts.app')
@section('contents')
@section('title')
    Digital Form Create
@endsection
<style>
    [dir="ltr"] {
        direction: ltr;
        text-align: left;
    }
</style>
<div class="page-wrapper">
    <div class="content">

        <!-- /add -->
        <form action="{{ route('digital.form.store') }}" class="form" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="card">
                <div class="card-header">
                    <h4> Create Digital Form</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card bg-white">
                                <div class="card-body">

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label for="title" class="col-sm-2 col-form-label">Name <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <input class="form-control slug-input" type="text" name="title"
                                                        placeholder="Enter name" value="{{ old('name') }}">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label class="col-sm-2 col-form-label" for="name">Add
                                                    Description<span class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control basic-conf" placeholder="Description.." name="desc" style="height: 150px"></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label class="col-sm-2 col-form-label" for="name">Add Mail
                                                    Message<span class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control basic-conf" placeholder="Description.." name="mail_desc" style="height: 150px"
                                                        id="summernotemail"></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label class="col-sm-2 col-form-label" for="name">Success
                                                    Message<span class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="success_message"
                                                        placeholder="Enter Success Message"
                                                        value="{{ old('success_message') }}">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label class="col-sm-2 col-form-label" for="name">Failure
                                                    Message<span class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="failure_message"
                                                        placeholder="Enter Failure Message"
                                                        value="{{ old('failure_message') }}">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3 row">
                                                <label class="col-sm-2 col-form-label" for="name">Receiver mail<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="receiver_mail"
                                                        placeholder="Enter Receiver mail" value="">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Toggle Switch -->
                                        <div class="form-check form-switch mb-3">
                                            <input class="form-check-input" type="checkbox" id="switchheader"
                                                name="header_status">
                                            <label class="form-check-label" for="switchheader">Enable Invoice
                                                Fields?</label>
                                        </div>

                                        <!-- Invoice Fields - hidden by default -->
                                        <div id="invoiceFields" style="display: none;">
                                            <div class="row">
                                                <div class="col-md-4 mb-3">
                                                    <label for="invoice_to" class="form-label">Invoice To</label>
                                                    <input type="text" class="form-control" name="invoice_to"
                                                        id="invoice_to">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="invoice_from" class="form-label">Invoice From</label>
                                                    <input type="text" class="form-control" name="invoice_from"
                                                        id="invoice_from">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="sia" class="form-label">SIA</label>
                                                    <input type="text" class="form-control" name="sia"
                                                        id="sia">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="vat" class="form-label">VAT</label>
                                                    <input type="text" class="form-control" name="vat"
                                                        id="vat">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="tax_date" class="form-label">Tax Date</label>
                                                    <input type="date" class="form-control" name="tax_date"
                                                        id="tax_date">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="invoice_number" class="form-label">Invoice
                                                        Number</label>
                                                    <input type="text" class="form-control" name="invoice_number"
                                                        id="invoice_number">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="terms" class="form-label">Terms</label>
                                                    <input type="text" class="form-control" name="terms"
                                                        id="terms">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="due_date" class="form-label">Due Date</label>
                                                    <input type="date" class="form-control" name="due_date"
                                                        id="due_date">
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="invoice_date" class="form-label">Date of
                                                        Invoice</label>
                                                    <input type="date" class="form-control" name="invoice_date"
                                                        id="invoice_date">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer text-end">
                                            <button type="submit"
                                                class="btn btn-submit p-2 btn-primary">Save</button>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <!-- /add -->
    </div>
</div>
@endsection
@section('scripts')
<!-- include libraries(jQuery, bootstrap) -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.js"></script>
<script>
    $(document).ready(function() {
        $('#summernotemail').summernote();
    });
</script>
<script>
    $(document).ready(function() {
        $('#switchheader').change(function() {
            if ($(this).is(':checked')) {
                $('#invoiceFields').slideDown();
            } else {
                $('#invoiceFields').slideUp();
            }
        });
    });
</script>
@endsection
