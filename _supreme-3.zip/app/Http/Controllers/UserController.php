<?php

namespace App\Http\Controllers;

use Notify;
use Carbon\Carbon;
use App\Models\Site;
use App\Models\User;
use App\Models\Shift;
use App\Models\Client;
use App\Helpers\Logger;
use App\Models\Invoice;
use App\Models\Document;
use App\Models\Employee;
use App\Models\Location;
use App\Models\CheckCall;
use App\Models\ShiftDate;
use Illuminate\Support\Str;
use App\Models\BookingAlarm;
use App\Models\Notification;
use App\Models\ShiftBooking;
use Illuminate\Http\Request;
use App\DataTables\UsersDataTable;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use App\Services\FileCompressor;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function dashboard()
    {
        if(auth()->user()->hasRole('client')){
            return redirect()->route('client.dashboard');
        }

        $this->pruneOldNotifications();

        
        // Today's shift dates: select only needed columns to reduce payload
        $shifts = ShiftDate::whereDate('shift_date', Carbon::today()->toDateString())
            ->select('id', 'shift_id', 'staff_id', 'shift_date', 'start_time', 'end_time')
            ->with([
                'shift'
            ])->get();

        // Use direct count queries (avoid fetching entire collections)
        $invoices = Invoice::whereNotNull('client_id')->count();
        $review = ShiftDate::where('is_assign', '1')->count();
        $clients = Client::count();
        $staffs = User::role('security_staff')->count();

        // Limit columns and eager-load only necessary shiftDate fields
        $checkCalls = CheckCall::select('id', 'shift_id', 'name', 'scheduled_time', 'status')
            ->with(['shiftDate' => function ($q) {
                $q->select('id', 'shift_date', 'shift_id');
            }])
            ->whereIn('status', ['pending', 'missed', 'completed'])
            ->whereHas('shiftDate', function ($q) {
                $q->whereBetween('scheduled_time', [
                    now()->startOfDay(),
                    now()->addDay()->endOfDay()
                ]);
            })
            ->orderBy('scheduled_time', 'desc')
            ->limit(20)
            ->get();

        $now = Carbon::now();

        $bookings = ShiftBooking::select('id', 'user_id', 'shift_id', 'type', 'timestamp')
            ->with(['shift'])
            ->whereHas('shift')
            ->orderBy('timestamp', 'desc')
            ->take(10)
            ->get();

        $today = Carbon::today();

        $siaDocuments = Employee::whereNotNull('sia_licence')
            ->whereDate('sia_expiry', '<', Carbon::today()->toDateString())
            ->select('fore_name', 'sur_name', 'sia_expiry', 'sia_licence_file')
            ->take(50)
            ->paginate(10);



        $this->missedShiftNotifications();
        
        // --- Users (latest locations) ---
        // Cache this expensive lookup for a short period (60s) to improve dashboard response
        $cutoff24 = Carbon::now()->subDay();
        $cacheKeyUsers = 'dashboard_user_locations_' . $cutoff24->toDateString();
        $userLocations = Cache::remember($cacheKeyUsers, 60, function () use ($cutoff24) {
            return Location::with([
                'user:id,first_name,last_name',
                'user.employee:id,user_id,service_type',
            ])
                ->whereNotNull('latitude')
                ->whereNotNull('longitude')
                ->whereIn('id', function ($query) use ($cutoff24) {
                    $query->select(DB::raw('MAX(id)'))
                        ->from('locations')
                        ->whereNotNull('user_id')
                        ->where('created_at', '>=', $cutoff24)
                        ->groupBy('user_id');
                })
                ->get()
                ->map(function ($l) {
                    return [
                        'id' => 'user-' . $l->user_id,
                        'latitude' => (float) $l->latitude,
                        'longitude' => (float) $l->longitude,
                        'name' => optional($l->user)->first_name . ' ' . optional($l->user)->last_name,
                        'type' => 'user',
                        'service_type_id' => optional(optional($l->user)->employee)->service_type,
                        'accuracy' => $l->accuracy,
                        'on_duty' => (bool) $l->on_duty,
                        'timestamp' => optional($l->created_at)->toDateTimeString(),
                    ];
                });
        });

        // --- Sites (pass postal codes only, no server-side geocoding) ---
        // Only include sites which have shifts with assigned staff in the last 7 days
        $sevenDaysAgo = Carbon::now()->subDays(7)->startOfDay();
        $sites = Site::query()
            ->select('sites.id', 'sites.site_name', 'sites.post_code', 'sites.address')
            ->join('shifts', 'shifts.site_id', '=', 'sites.id')
            ->join('shift_dates', 'shift_dates.shift_id', '=', 'shifts.id')
            ->whereNotNull('shift_dates.staff_id')
            ->where('shift_dates.shift_date', '>=', $sevenDaysAgo)
            ->distinct()
            ->get();

        // Cache site locations for a slightly longer period (5 minutes)
        $cacheKeySites = 'dashboard_site_locations_' . now()->startOfDay()->toDateString();
        $siteLocations = Cache::remember($cacheKeySites, 300, function () use ($sites) {
            return $sites->map(function ($site) {
                return [
                    'id' => 'site-' . $site->id,
                    'name' => $site->site_name,
                    'postalcode' => $site->post_code,
                    'address' => $site->address,
                    'type' => 'site',
                ];
            });
        });

        $this->weeklyHoursNotification();

        // --- Merge users and sites for frontend ---
        $apiKey = env('GOOGLE_MAPS_API_KEY');
        return view('dashboard', compact('apiKey', 'siaDocuments', 'bookings', 'checkCalls', 'clients', 'staffs', 'shifts', 'invoices', 'review', 'userLocations', 'siteLocations'));
    }

    public function index(UsersDataTable $dataTable)
    {
        $roles = Role::pluck('name', 'name')->all();
        return $dataTable->render('user_management.users', compact('roles'));
    }

    public function create()
    {
        $roles = Role::pluck('name', 'name')->all();
        return view('role-permission.user.create', ['roles' => $roles]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'nullable|string|max:255',
            // 'username' => 'required|string|unique:users,username',
            'email' => 'required|email:dns|unique:users,email,NULL,id,deleted_at,NULL',
            'password' => 'required|confirmed',
            'phone_number' => 'nullable|string|max:20',
            'status' => 'nullable|string',
            'roles' => 'nullable|array',
            'profile_picture' => 'nullable|image|max:4096'
        ]);

        if ($validator->fails()) {
            if ($request->ajax()) {
                return response()->json(['errors' => $validator->errors()], 422);
            } else {
                return redirect()->back()->withErrors($validator)->withInput();
            }
        }

        $validated = $validator->validated();
        $validated['password'] = Hash::make($validated['password']);
        $validated['username'] = $validated['email'];

        // Handle profile picture upload
        if ($request->hasFile('profile_picture')) {
            $uploadPath = public_path('uploads/profile_pictures');
            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath, 0755, true);
            }

            $file = $request->file('profile_picture');
            $fileName = time() . '_profile.' . $file->getClientOriginalExtension();
            $file->move($uploadPath, $fileName);

            $validated['profile_picture'] = $fileName;
            try {
                (new FileCompressor())->compress($uploadPath . '/' . $fileName);
            } catch (\Exception $e) {
                Log::error('File compression failed for user profile_picture: ' . $e->getMessage());
            }
        }

        $user = User::create($validated);

        if (!empty($validated['roles'])) {
            $user->assignRole($validated['roles']);
        }
        Logger::log(Auth::user(), 'Create', 'New user ' . $user->first_name . ' ' . $user->last_name);

        return response()->json(['message' => 'User created successfully']);
    }
    public function edit($id)
    {
        $user = User::find($id);
        $roles = Role::pluck('name', 'name')->all();
        $userRoles = $user->roles->pluck('name', 'name')->all();
        return response()->json(['user' => $user, 'userRoles' => $userRoles]);
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found.'], 404);
        }

        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'nullable|string|max:255',
            // 'username' => 'required|string|unique:users,username,' . $id,
            'email' => 'required|email:dns|unique:users,email,' . $id . ',id,deleted_at,NULL',
            'password' => 'nullable|confirmed',
            'phone_number' => 'nullable|string|max:20',
            'status' => 'nullable|string',
            'roles' => 'nullable',
            'profile_picture' => 'nullable|image|max:4096'
        ]);

        if ($validator->fails()) {
            if ($request->ajax()) {
                return response()->json(['errors' => $validator->errors()], 422);
            } else {
                return redirect()->back()->withErrors($validator)->withInput();
            }
        }

        $validated = $validator->validated();
        $validated['username'] = Str::slug($validated['first_name'] . $validated['last_name']) . rand(1, 100);

        if (!empty($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        if ($request->hasFile('profile_picture')) {
            $uploadPath = public_path('uploads/profile_pictures');
            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath, 0755, true);
            }

            $file = $request->file('profile_picture');
            $fileName = time() . '_profile.' . $file->getClientOriginalExtension();
            $file->move($uploadPath, $fileName);

            $validated['profile_picture'] = $fileName;
            try {
                (new FileCompressor())->compress($uploadPath . '/' . $fileName);
            } catch (\Exception $e) {
                Log::error('File compression failed for user profile_picture (update): ' . $e->getMessage());
            }
        }

        $user->update($validated);

        if (!empty($validated['roles'])) {
            $user->syncRoles($validated['roles']);
        }
        Logger::log(Auth::user(), 'Update', 'User ' . $user->first_name . ' ' . $user->last_name . ' Updated');

        return response()->json(['message' => 'User updated successfully']);
    }

    public function destroy($userId)
    {
        // \Log::info("Destroy called for user: " . $userId);
        $user = User::findOrFail($userId);
        Logger::log(Auth::user(), 'Delete', 'User ' . $user->first_name . ' ' . $user->last_name . ' Deleted');

        $user->delete();

        // $stillExists = User::find($userId);
        // \Log::info('Still exists after delete? ' . ($stillExists ? 'YES' : 'NO'));
        return response()->json(['success' => true]);
    }
    public function bulkDelete(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:users,id',
        ]);

        $users = User::whereIn('id', $request->ids)->get();
        foreach ($users as $user) {
            Logger::log(Auth::user(), 'Delete', 'User ' . $user->first_name . ' ' . $user->last_name . ' Deleted');
            $user->delete();
        }

        return response()->json(['message' => 'Selected users deleted.']);
    }
    public function getLogs($id)
    {
        $user = User::with('logs')->findOrFail($id);

        return response()->json([
            'logs' => $user->logs->map(function ($log) {
                return [
                    'user_name' => $log->user_name,
                    'action' => $log->action,
                    'description' => $log->description,
                    'time' => $log->created_at->diffForHumans(),
                    'success' => 'success',
                ];
            })
        ]);
    }
    public function view($id)
    {
        $user = User::findOrFail($id);

        return response()->json([
            'name' => $user->name,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'email' => $user->email,
            'username' => $user->username,
            'phone_number' => $user->phone_number,
            'status' => ucfirst($user->status),
            'profile_picture' => $user->profile_picture ? asset('uploads/profile_picture/' . $user->profile_picture) : null,
        ]);
    }

    // booking function 
    public function acknowledge(Request $request, $id)
    {
        $alarm = BookingAlarm::findOrFail($id);
        $alarm->acknowledged = true;
        $alarm->save();

        return response()->json(['success' => true]);
    }

    public function weeklyHoursNotification()
    {
        $today = \Carbon\Carbon::now();

        // Only run on Thursday
        if (!$today->isThursday()) {
            return;
        }

        // ✅ Prevent duplicate runs: cache key for this Thursday
        $cacheKey = 'weekly_hours_notification_' . $today->toDateString();

        if (Cache::has($cacheKey)) {
            return; // Already sent today
        }

        $weekStart = $today->copy()->startOfWeek(\Carbon\Carbon::MONDAY)->format('Y-m-d');
        $weekEnd   = $today->copy()->endOfWeek(\Carbon\Carbon::SUNDAY)->format('Y-m-d');

        $guards = \App\Models\Employee::where('sia_status', 'Active')
            ->orWhere('sia_status', 'valid')
            ->get();

        foreach ($guards as $staff) {
            $entity = $staff->entity;
            $minWeeklyHours = $entity->hour_per_week ?? 40;

            $totalWeekHours = \App\Models\ShiftDate::where('staff_id', $staff->user_id)
                ->whereBetween('shift_date', [$weekStart, $weekEnd])
                ->sum('total_hours');

            if ($totalWeekHours < $minWeeklyHours) {
                $expectedHours = $totalWeekHours;

                Notify::toDashboard(
                    null,
                    'alert',
                    'Worked Hours',
                    "Guard {$staff->fore_name} {$staff->sur_name} has only {$expectedHours} hours scheduled this week. Minimum is {$minWeeklyHours}.",
                    "#"
                );
            }
        }

        // ✅ Store flag in cache until the end of Thursday (23:59:59)
        Cache::put($cacheKey, true, $today->copy()->endOfDay());
    }

    /**
     * Prune notifications older than 15 days. Runs at most once per day (cache-guarded).
     */
    private function pruneOldNotifications()
    {
        // Use a file-based lock in storage to avoid dependency on Cache driver availability
        $lockFile = storage_path('app/pruned_notifications_' . now()->format('Ymd') . '.lock');
        if (file_exists($lockFile)) {
            return; // already pruned today
        }

        try {
            $old = \App\Models\Notification::where('created_at', '<', now()->subDays(15))->get();
            $count = $old->count();
            if ($count > 0) {
                foreach ($old as $n) {
                    try {
                        $n->forceDelete();
                    } catch (\Exception $ex) {
                        \Log::warning('Failed to forceDelete notification id ' . $n->id . ': ' . $ex->getMessage());
                    }
                }
                \Log::info("Pruned {$count} notifications older than 15 days.");
            }
        } catch (\Exception $e) {
            // swallow — pruning is best-effort; log for visibility
            \Log::error('Notification pruning failed: ' . $e->getMessage());
        }

        // create the lock file to mark pruning done for today (best-effort)
        try {
            $dir = dirname($lockFile);
            if (!file_exists($dir)) {
                \Illuminate\Support\Facades\File::makeDirectory($dir, 0755, true);
            }
            @file_put_contents($lockFile, now()->toDateTimeString());
        } catch (\Exception $e) {
            \Log::warning('Failed to create prune lock file: ' . $e->getMessage());
        }
    }

    /**
     * Missed / Unassigned shift notifications.
     * - Uses `ShiftDate` model (per-shift entry) instead of `Shift`.
     * - Uses a per-hour global cache to avoid running the whole check more than once an hour.
     * - Uses per-shift cache keys so each shift is notified at most once per hour.
     */
    private function missedShiftNotifications()
    {
        $hourKey = 'missed_shifts_checked_' . now()->format('Y-d-mH');
        if (Cache::has($hourKey)) {
            return; // Already ran in this hour
        }

        $now = now();
        // limit checks to shift_dates within the last 24 hours to avoid scanning historic data
        $cutoff24 = $now->copy()->subDay()->toDateString();

        // --- Missed Book On Notifications ---
        $missedBookOns = ShiftDate::whereNotNull('staff_id')
            ->whereNull('absentee_start_time')
            ->whereBetween('shift_date', [$cutoff24, $now->toDateString()])
            ->whereTime('start_time', '<=', $now->copy()->subMinutes(15)->format('H:i:s'))
            ->select('id', 'staff_id', 'start_time', 'shift_date', 'is_assign')
            ->get();

        // --- Missed Book Off Notifications ---
        $missedBookOffs = ShiftDate::whereNotNull('staff_id')
            ->whereNull('absentee_end_time')
            ->whereBetween('shift_date', [$cutoff24, $now->toDateString()])
            ->whereTime('end_time', '<=', $now->copy()->subMinutes(15)->format('H:i:s'))
            ->select('id', 'staff_id', 'end_time', 'shift_date')
            ->get();

        // collect staff ids to eager-load once
        $staffIds = collect($missedBookOns)->pluck('staff_id')->merge(collect($missedBookOffs)->pluck('staff_id'))->unique()->filter()->values()->all();
        $staffMap = [];
        if (!empty($staffIds)) {
            $staffMap = User::whereIn('id', $staffIds)
                ->select('id', 'first_name', 'last_name')
                ->get()
                ->keyBy('id');
        }

        foreach ($missedBookOns as $sd) {
            if ($sd->is_assign == 2) {
                $perShiftKey = 'missed_shift_on_' . $sd->id;
                if (Cache::has($perShiftKey)) {
                    continue;
                }

                $employee = $staffMap[$sd->staff_id] ?? null;
                $guardName = $employee ? "{$employee->first_name} {$employee->last_name}" : 'Unknown';

                Notify::toDashboard(
                    $employee?->id,
                    'alarm',
                    'Missed Book On',
                    "Guard {$guardName} did not book on for their shift starting at {$sd->start_time} on {$sd->shift_date}.",
                    "/shift-dates/{$sd->id}/view"
                );

                Cache::put($perShiftKey, true, now()->addHour());
            }
        }

        foreach ($missedBookOffs as $sd) {
            $perShiftKey = 'missed_shift_off_' . $sd->id;
            if (Cache::has($perShiftKey)) {
                continue;
            }

            $employee = $staffMap[$sd->staff_id] ?? null;
            $guardName = $employee ? "{$employee->first_name} {$employee->last_name}" : 'Unknown';

            Notify::toDashboard(
                $employee?->id,
                'alarm',
                'Missed Book Off',
                "Guard {$guardName} did not book off for their shift ending at {$sd->end_time} on {$sd->shift_date}.",
                "/shift-dates/{$sd->id}/view"
            );

            Cache::put($perShiftKey, true, now()->addHour());
        }

        // --- Unassigned Shift Starting Soon ---
        $unassignedShiftDates = ShiftDate::whereNull('staff_id')
            ->whereDate('shift_date', '=', $now->toDateString())
            ->whereTime('start_time', '>=', $now->format('H:i:s'))
            ->whereTime('start_time', '<=', $now->copy()->addHour()->format('H:i:s'))
            ->get();

        foreach ($unassignedShiftDates as $sd) {
            $perShiftKey = 'unassigned_shift_' . $sd->id;
            if (Cache::has($perShiftKey)) {
                continue;
            }

            Notify::toDashboard(
                null,
                'alarm',
                'Unassigned Shift',
                "A shift at {$sd->start_time} on {$sd->shift_date} is starting soon and no guard has been assigned.",
                "/shift-dates/{$sd->id}/view"
            );

            Cache::put($perShiftKey, true, now()->addHour());
        }

        // --- Assigned Shifts Starting Soon and not accepted ---
        $unassignedShiftDates = ShiftDate::whereNotNull('staff_id')
            ->whereDate('shift_date', '=', $now->toDateString())
            ->whereTime('start_time', '>=', $now->format('H:i:s'))
            ->whereTime('start_time', '<=', $now->copy()->addHour()->format('H:i:s'))
            ->get();

        foreach ($unassignedShiftDates as $sd) {
            if($sd->is_assign !== 2){
                $perShiftKey = 'unaccepted_shift_' . $sd->id;
                if (Cache::has($perShiftKey)) {
                    continue;
                }
    
                Notify::toDashboard(
                    null,
                    'alarm',
                    'Unaccepted Shift',
                    "A shift at {$sd->start_time} on {$sd->shift_date} is starting soon and The guard did not accept.",
                    "/shift-dates/{$sd->id}/view"
                );
    
                Cache::put($perShiftKey, true, now()->addHour());
            }
        }

        // Mark the overall check as done for this hour
        Cache::put($hourKey, true, now()->addHour());
    }
}
